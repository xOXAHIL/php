﻿**HOTEL BOOKING SYSTEM** 

*Project report (CA3) submitted in fulfilment of the requirements for the Degree of*

**BACHELOR OF TECHNOLOGY  in**   

**COMPUTER SCIENCE AND ENGINEERING**  

By    

**SAHIL PATIYal**  

**(12016885)**  SUBJECT  

**INT220 - SERVER SIDE SCRIPTING** 

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.001.png)

**School of Computer Science and Engineering** 

Lovely Professional University   Phagwara, Punjab (India)        November 2023  

**TABLE OF CONTENTS**  



|S. No. |Topics |Page No. |
| - | - | - |
|1\. |Introduction |3-4 |
|2\. |Technologies Used |4-6 |
|3\.  |Modules |7-8 |
|4\. |Snapshots |9-15 |
|5\. |Database |15-22 |
|6\. |Project link |22 |
|7\. |Bibliograph |23 |

**INTRODUCTION**  

In the fast-paced world of today, mobility is a key factor in meeting the              demands of a dynamic lifestyle. The advent of technology has transformed the way we approach transportation, and one of the manifestations of this transformation is the rise of online car rental services. These services offer a convenient and flexible solution for individuals seeking temporary access to vehicles without the burden of ownership.        Developed with an emphasis on accessibility, the Heritage Hotel Booking System         boasts an interface designed for simplicity and ease of use. Its user-friendly design        ensures that individuals, irrespective of their technological acumen, can effortlessly       navigate the application. Leveraging HTML as the foundational interface language and PHP for server-side scripting, the system interacts harmoniously with the Apache          server, resulting in a dynamic platform accessible through standard web browsers.  

This report delves into the creation and implementation of an Online Car Rental Application using PHP and MySQL—a robust and widely-used combination for web development. The application provides users with a seamless platform to browse, select, and book rental cars, offering a user-friendly interface and efficient data management.  

Data security and integrity are paramount considerations in the system's architecture. The incorporation of a MySQL database serves as the backbone, enhancing the reliability and confidentiality of stored user information. This meticulous approach not only safeguards sensitive data but also contributes to the overall robustness and trustworthiness of the application.  

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.002.png) ![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.003.png)

The primary objective of this project is to design and develop an intuitive and secure online car rental system that caters to the diverse needs of users. Utilizing PHP for server-side scripting and MySQL for database management, the application aims to streamline the car rental process, making it accessible and user-friendly. processes, the system guides users through each step. Upon completion, users are promptly furnished with a confirmation email, providing a detailed summary of their reservation and enhancing the overall user experience.  

**TECHNOLOGIES USED**  

The Online Car Rental is underpinned by a sophisticated technological framework that seamlessly integrates various programming languages and tools to deliver a robust and user-centric experience. The primary technologies employed in this project include PHP, Bootstrap, MySQL WorkBench, and JavaScript, each playing a crucial role in enhancing the functionality, aesthetics, and overall performance of the web-based application.  

1. **PHP (Hypertext Preprocessor):**  

At the core of the Heritage Hotel Booking System is PHP, a server-side scripting language renowned for its versatility and efficiency. PHP facilitates dynamic content generation, enabling seamless interaction between the user interface and the server. Its usage in this project ensures the smooth execution of server-side operations, making real-time data processing, such as booking validations and user authentication, possible.  

2. **Bootstrap:**  

The utilization of Bootstrap, a front-end framework, significantly enhances the visual appeal and responsiveness of the Heritage Hotel Booking System. Bootstrap's pre-designed templates and responsive grid system facilitate the creation of a mobilefriendly and aesthetically pleasing user interface. This ensures a consistent and engaging experience for users across various devices, contributing to the overall accessibility of the application.  

3. **MySQL Workbench:**  

MySQL Workbench is a powerful and intuitive visual tool designed for database architects, developers, and administrators working with MySQL databases. Developed by Oracle Corporation, MySQL Workbench provides a comprehensive environment for database design, modelling, development, and administration.  

4. **MySQL:**  

MySQL is a popular open-source relational database management system, widely recognized for its reliability and performance. In the Online Voting System, MySQL is used as the database backend to store and manage critical data such as voter information, candidate details, election parameters, and voting results. Key aspects of MySQL's contribution include:  

Data Storage: MySQL efficiently stores and organizes all the essential data related to Locations, Hotels, Rooms, Booking, Contacts and Users along with Users Type in structured tables.  

Data Retrieval: It provides powerful SQL querying capabilities, enabling the system to retrieve and present data to users as needed.  

Data Integrity: MySQL ensures data integrity and security, enforcing constraints and permissions to prevent unauthorized access or data corruption.  

Scalability: MySQL's scalability supports the growth of the voting system, making it capable of handling elections of varying sizes.  

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.004.png)

5. **JavaScript:**  

JavaScript, a versatile scripting language, is employed to enhance the interactivity and responsiveness of the Heritage Hotel Booking System. Leveraging JavaScript allows for dynamic content updates without requiring a page refresh, contributing to a more seamless and engaging user experience. Additionally, it facilitates client-side form validation, ensuring data accuracy and enhancing the overall reliability of user inputs.  

6. **XAMPP:**  

XAMPP, an acronym for cross-platform, Apache, MySQL, PHP, and Perl, is an open-source web server solution that simplifies the process of setting up a local development environment. Its role in the development of the Online Voting System includes:  

Local Development: XAMPP provides an all-in-one package that includes the Apache web server, MySQL database, PHP, and other necessary components, allowing developers to set up and test the system on their local machines.  

Debugging and Testing: XAMPP aids in debugging and testing the voting system, ensuring that it functions correctly before deployment to a production server.  

Portability: The system can be easily transferred to a production server from the local XAMPP environment when it's ready for live use.  

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.005.png)

**MODULES**  

1. **User Authentication:**  

The project initiation involves a robust user authentication system, a cornerstone for securing access to the Online Car Rental home page exclusively for logged-in users. Unauthorized visitors are seamlessly rerouted to the login page, thereby fortifying the security infrastructure and enriching the overall user experience.  

Beyond the conventional login mechanism, the system employs advanced security measures during the user signup process. When a user creates an account, the system stores the password in a hashed format, enhancing the security of sensitive user information. This hashed password serves as a resilient shield, rendering the actual password indecipherable even in the event of unauthorized access to the database.  During the login process, the system ensures the utmost security by converting the provided login password string into a hash. This hashed password is then compared with the stored hashed password in the database, ensuring a secure and robust authentication process. This dual-layered approach not only safeguards user accounts from potential breaches but also underscores the project's commitment to adopting contemporary security practices.  

The user authentication system, fortified by secure storage and verification of passwords, establishes a solid foundation for user interactions within the Online Car Rental. It reflects a commitment to prioritizing user data privacy and security, ensuring that every aspect of the user journey aligns with the highest standards of digital security.  

2. **Car Discovery and Filtering:**  

Once logged in, users are presented with an extensive array of Cars, enriched with diverse filter options. The filtering mechanism empowers users to tailor their search based on preferences, creating a personalized car exploration journey.  

3. **Car Details and Features:**  

Upon selecting a car, users are ushered into a detailed view of the establishment. The system provides comprehensive information about the car, including available seats and accessories. This immersive experience aids users in making informed decisions about their preferences.  

4. **Booking Summary and Guest Information:**  

The user journey extends to a booking summary page, where intricate details about the chosen brand and car. Users are seamlessly guided to input  information, completing the reservation process with ease and efficiency.  

5. **Date Filtering for Booking:**  

Adding a layer of flexibility, the application allows users to enter rent-in and rentout dates via a user-friendly filter. This feature enables users to align their reservations with their travel itinerary, adding a valuable dimension to the booking experience.  

6. **Admin Panel Operations:**  

The administrative facet of the project introduces a powerful Admin Panel, providing administrators with the capability to perform CRUD (Create, Read, Update, Delete) operations on key modules. From managing brands and cars to overseeing booked cars and un booked cars, administrators wield a comprehensive suite of tools to maintain and optimize the system.  

In conclusion, the Online Car Rental Web App transcends the conventional boundaries of reservation platforms. It not only simplifies the booking process for users but also empowers administrators with robust tools for system management. This project is a testament to the seamless integration of technology and hospitality, offering a glimpse into the future of digital car rental reservations.  

**SNAPSHOTS**  

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.006.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.007.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.008.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.009.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.010.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.011.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.012.jpeg)

Admin Login 

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.013.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.014.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.015.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.016.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.017.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.018.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.019.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.020.jpeg)

**DATABASE**  

In my project, I have employed MySQL Workbench as the database management system, which offers a robust foundation for storing and managing critical data through ten distinct tables: admin, tblbooking, tblbrands, tblcontactusinfo,  tblcontactusquery, tblpages, tblsubscribers, tbltestimonials, tblusers,tblvehicles. Each table plays a specific role in the functionality of my project:  

**admin:**  

This table is responsible for storing detailed information about admin. It typically includes information about admin. 

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.021.jpeg)

**tblbooking:**  

This table is responsible for storing records of booked cars by users. It typically includes fields such as vehicleID, FromDate, ToDate, message.  

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.022.jpeg)

**tblbrands:**  

This table is responsible for maintaining records of cars along with their brands they belong to, entered by admin. It typically includes fields such as BrandName, CreationDate, UpdationDate.  

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.023.jpeg)

**tblcontactusinfo:**  

This table is responsible for maintaining records of users that have contacted admin for some queries. 

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.024.jpeg)

**tblpages:** 

this table stores data of different pages in my website such as Terms And condition page, Privacy and policy , About Us and FAQs. 

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.025.jpeg)

**Tblsubscriberes:** 

` `This table is responsible for maintaining records of users that have subscribed our website. 

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.026.jpeg)

**Tbltestimonial:** 

This table is responsible for maintaining records of users that have provided their feedback. 

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.027.jpeg)

**Tblusers:** 

This table is responsible for maintaining records of users credentials such as id and passwords but users password is in hash form to provide security . 

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.028.jpeg)

` `**Tblvehicles:** 

This table is responsible for maintaining records of vehicles such as how many vehicles are there and its name , features , accessories. 

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.029.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.030.jpeg)

**PROJECT LINK               [https://github.com/xOXAHIL/php** ](https://github.com/xOXAHIL/php)**

**BIBLIOGRAPHY**  

1. **PHP Documentation:**  
- Author: The PHP Group  
- URL: https://www.php.net/manual/en/ 
2. **MySQL Documentation:**  
- Author: Oracle Corporation  
- URL: https://dev.mysql.com/doc/ 
3. **Bootstrap Documentation:**  
- Author: The Bootstrap Authors  
- URL: https://getbootstrap.com/docs/4.0/ 
4. **JavaScript Documentation:**  
- Author: Mozilla Developer Network (MDN)  
- URL: https://developer.mozilla.org/en- US/docs/Web/JavaScript  
5. **PhpMyAdmin Documentation:**  
- Author: PhpMyAdmin team  
- URL: https://docs.phpmyadmin.net/ 

**Coding Part :** 

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.031.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.032.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.033.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.034.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.035.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.036.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.037.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.038.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.039.jpeg)

![](Aspose.Words.26a5683d-d2f7-4904-aa07-261f2713a18f.040.jpeg)

**CHAPTERS COVERED:**  

**CH – 1:**  

PHP, MYSQL, XAMPP, PHP Arrays, PHP Constants, PHP Expressions, PHP Operators, PHP Control Structures, PHP Loops. 

**CH – 2:** 

**PHP Arrays and Functions: PHP Enumerated Arrays, PHP Associative Arrays, PHP Multi-Dimensional Arrays, PHP Functions, Syntax, Arguments and Variables, References, Pass by Value & Pass by references, Return Values, Variable Scope, PHP include() and PHP require()** 

**CH-3:** 

PHP Forms : PHP Form handling, PHP GET and POST, PHP Form Validation, PHP Form Sanitization 

**CH – 4:** 

PHP String Handling, PHP Login Session, Strings and Patterns, Matching, PHP Sending Emails, PHP File Uploading, PHP Filters, PHP Error Handling. 

**CH-5:** 

Object Oriented Programming in PHP : Defining PHP Classes, Creating Objects in PHP, Calling Member Functions, Constructor Functions, Inheritance, Function Overriding, Interface, Abstract Classes 

**CH-6:** 

**Basic MySQL and SQL Queries :** Database Basics, Indexes, PHP MyAdmin, Connect & Pconnect, MySQL Create, MySQL Insert, MySQL Select, MySQL Update, MySQL Delete, MySQL Truncate, MySQL Drop, WHERE condition, Order By and Group By, Having, LIKE, AND OR operators, SQL functions AVG, COUNT, SUM, MIN, MAX, LCASE, UCASE 
Page 31** of 31** 
